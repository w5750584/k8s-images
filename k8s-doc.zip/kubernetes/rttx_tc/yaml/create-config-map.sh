#!/bin/sh
ls *.properties | while read line;do
	#file=`echo $line | awk -F '.' '{print $1}'`
	#echo $file
	#kubectl delete configmap $line -n tc
	kubectl create configmap $line --from-file=./$line -n tc
	#new_file=`echo $line | sed 's/_/-/g'`
	#mv $line $new_file
done
