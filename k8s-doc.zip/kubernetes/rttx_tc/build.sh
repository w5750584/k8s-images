#!/bin/bash
build_dubbo(){
	rm Dockerfile -f
	version=`date +%Y%m%d_%H%M%S`
	cat >Dockerfile <<-EOF
	FROM docker.zyxr.com/rttx_tc_dubbo/tc-parent-dubbo:latest 
	RUN mkdir -p /data/service
	COPY $1 /data/service/$1
	CMD ["bash","/data/service/$1/bin/start.sh"] 
	EOF
	if [ "$2" == "jdk" ];then
		sed -i "s/latest/jdk8/g" Dockerfile
	fi
	docker build . -t docker.zyxr.com/rttx_tc_dubbo/$1:$version
	docker push docker.zyxr.com/rttx_tc_dubbo/$1:$version
	docker rmi -f docker.zyxr.com/rttx_tc_dubbo/$1:$version
	echo -e "镜像地址: \033[31;1mdocker.zyxr.com/rttx_tc_dubbo/$1:$version\033[0m"
	deploy_name=`echo $1  | awk -F 'tc-' '{print $NF}'`
	kubectl set image deployment/$deploy_name $deploy_name=docker.zyxr.com/rttx_tc_dubbo/$1:$version -n tc
#        kubectl get deploy -n tc | awk '{print $1}'| while read line;do
#                echo $1 | grep $line
#                if [ $? -eq 0 ];then
#                        kubectl set image deployment/$line $line=docker.zyxr.com/rttx_tc_resin/$1:$version -n tc
#                fi
#        done
}

build_resin(){
	rm Dockerfile -f
	version=`date +%Y%m%d_%H%M%S`
	cat > Dockerfile <<-EOF
	FROM docker.zyxr.com/rttx_tc_resin/tc-parent-resin:latest 
	COPY $1/resin.xml /data/server/resin-platform-9093/conf/resin.xml
	COPY $1 /data/webapp/
	EOF
	docker build . -t docker.zyxr.com/rttx_tc_resin/$1:$version
	docker push docker.zyxr.com/rttx_tc_resin/$1:$version
	docker rmi -f docker.zyxr.com/rttx_tc_resin/$1:$version
	echo -e "镜像地址: \033[31;1mdocker.zyxr.com/rttx_tc_resin/$1:$version\033[0m"
	deploy_name=`echo $1  | awk -F 'tc-' '{print $NF}'`
	kubectl set image deployment/$deploy_name $deploy_name=docker.zyxr.com/rttx_tc_resin/$1:$version -n tc
#	kubectl get deploy -n tc | awk '{print $1}'| while read line;do
#		echo $1 | grep $line
#		if [ $? -eq 0 ];then
#			kubectl set image deployment/$line $line=docker.zyxr.com/rttx_tc_resin/$1:$version -n tc
#		fi
#	done
}
$1 $2 $3
