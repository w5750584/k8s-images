#!/bin/bash
if [ $1 == '' ];then
    echo "缺少命名空间"
	echo "./deploy.sh 命名空间"
    exit 1
else
    kubectl get ns | grep $1
    if [ $? == '1' ];then
        echo "命名空间已存在"
        exit 2
    fi
fi

kubectl create configmap tomcat-server.xml --from-file=./server.xml -n $1

kubectl create configmap nodeport-nginx-conf --from-file=./nodeport-nginx-conf  -n $1

kubectl create -f service.yaml -n $1

kubectl create -f deploy-dubbo.yaml  -n $1

kubectl create -f deploy-tomcat.yaml  -n $1

kubectl create -f  deploy-NodePort.yaml -n $1