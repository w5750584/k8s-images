添加帐号：
1、在每个master的/etc/kubernetes/basic_auth_file文件中增加一行，格式<密码,帐户,uid,group> .
2、复制一份 devmanger.yaml 修改对应配置，然后执行kubecrl create -f 修改后的文件.