#!/bin/bash
kubectl create cm td-agent.conf --from-file=./td-agent.conf  -n kube-system
kubectl create -f k8splunk-ds.yaml -n kube-system