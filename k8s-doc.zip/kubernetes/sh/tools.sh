#!/bin/bash
nodes=(
192.168.9.24
192.168.9.25
192.168.9.26
192.168.9.27
192.168.9.28
192.168.9.29
192.168.9.31
192.168.9.32
192.168.9.33
192.168.9.34
)
set_nodeselect(){
kubectl get deploy -n $1 | awk '{print $1}' | while read line;do
	kubectl patch deploy $line -p '{"spec":{"template":{"spec":{"nodeSelector": {"sys_type": "rttx"}}}}}' -n $1
done
}
set_env(){
kubectl get deploy -n $1 | awk '{print $1}' | while read line;do
	kubectl patch deploy $line -p '{"spec":{"template":{"spec":{"containers":[{"name":"'$line'","env":[{"name": "k8s_ns","valueFrom": {"configMapKeyRef": {"name": "env-cfg","key": "namespace"}}}]}]}}}}' -n $1
done
}
set_rep(){
kubectl  get deploy -n $1 -o wide | grep tomcat | awk '{print $1}' | while read line;do
	kubectl scale --replicas=0 deployment/$line -n $1
done
}
fix_node(){
  for node in ${nodes[@]}
  do
	echo -e "\033[31;1m----在主机$node执行----\033[0m"
	ssh $node "$1 $2 $3 $4 $5 $6 $7 $8"
	#scp /root/.kube/config $node:/root/.kube/config
  done
}
$1 $2 $3 $4 $5 $6 $7 $8 $9
