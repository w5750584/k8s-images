#/bin/bash
#安装tomcat，dubbo，nginx，zk模版，需要预先创建好nfs存储

if [ $1 == '' ];then
    echo "缺少命名空间"
    exit 1
else
    kubectl get ns | grep $1
    if [ $? == '1' ];then
        echo "命名空间已存在"
        exit 2
    fi
fi

kubectl create -f ./dubbo.yaml -n $1