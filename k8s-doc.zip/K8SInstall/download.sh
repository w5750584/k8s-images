Version=v1.9.3
curl https://storage.googleapis.com/kubernetes-release/release/$Version/kubernetes-client-linux-amd64.tar.gz > kubernetes-client-linux-amd64.tar.gz
curl https://storage.googleapis.com/kubernetes-release/release/$Version/kubernetes-server-linux-amd64.tar.gz > kubernetes-server-linux-amd64.tar.gz



VersionTGZ=17.03.2
curl https://download.docker.com/linux/static/stable/x86_64/docker-$VersionTGZ-ce.tgz > docker-$VersionTGZ-ce.tgz


curl -o ./cfssl https://pkg.cfssl.org/R1.2/cfssl_linux-amd64
curl -o ./cfssljson https://pkg.cfssl.org/R1.2/cfssljson_linux-amd64

curl http://mirror.centos.org/centos/7/os/x86_64/Packages/expect-5.45-14.el7_1.x86_64.rpm > expect-5.45-14.el7_1.x86_64.rpm
curl http://mirror.centos.org/centos/7/os/x86_64/Packages/tcl-8.5.13-8.el7.x86_64.rpm > tcl-8.5.13-8.el7.x86_64.rpm

export ETCD_VERSION=v3.1.10
curl -sSL https://github.com/coreos/etcd/releases/download/${ETCD_VERSION}/etcd-${ETCD_VERSION}-linux-amd64.tar.gz > etcd-${ETCD_VERSION}-linux-amd64.tar.gz


flannelVersion="v0.10.0"
curl -sSL https://github.com/coreos/flannel/releases/download/$flannelVersion/flannel-${flannelVersion}-linux-amd64.tar.gz > flannel-${flannelVersion}-linux-amd64.tar.gz

