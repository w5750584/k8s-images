#!/bin/bash
Masters=(
192.168.9.21
192.168.9.22
192.168.9.23
)
Nodes=(
192.168.9.31
192.168.9.32
192.168.9.33
)
update_master(){
  mkdir -p /tmp/k8s_old/
  scp $Masters:/usr/local/bin/kube-apiserver /tmp/k8s_old/
  scp $Masters:/usr/local/bin/kube-controller-manager /tmp/k8s_old/
  scp $Masters:/usr/local/bin/kubectl /tmp/k8s_old/
  scp $Masters:/usr/local/bin/kube-scheduler /tmp/k8s_old/
  for master in ${Masters[@]}
  do
    ssh $master "service kube-apiserver stop"
    ssh $master "service kube-controller-manager stop"
    ssh $master "service kube-scheduler stop"
    scp kube-apiserver $master:/usr/local/bin/
    scp kube-controller-manager $master:/usr/local/bin/
    scp kubectl $master:/usr/local/bin/
    scp kube-scheduler $master:/usr/local/bin/
    ssh $master "service kube-apiserver restart"
    ssh $master "service kube-controller-manager restart"
    ssh $master "service kube-scheduler restart"
  done
}
update_node(){
  mkdir -p /tmp/k8s_old/
  scp $Nodes:/usr/local/bin/kubelet /tmp/k8s_old/
  scp $Nodes:/usr/local/bin/kube-proxy /tmp/k8s_old/
  for node in ${Nodes[@]}
  do
    ssh $node "service kubelet stop"
    ssh $node "service kube-proxy stop"
    scp kube-proxy $node:/usr/local/bin/
    scp kubelet $node:/usr/local/bin/
    scp kubectl $node:/usr/local/bin/
    ssh $node "service kubelet restart"
    ssh $node "service kube-proxy restart"
  done
}

$1
