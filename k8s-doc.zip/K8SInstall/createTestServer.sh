NS="test1"
MQManagerPort=9001
ZKPort=9002

declare -i n=1
rm test_env.yaml -rf
touch test_env.yaml
#redis
while ((n<=6));
do
name="redis${n}"
serverName="${name}-exserver"
cat >> test_env.yaml <<EOF
---
kind: Service
apiVersion: v1
metadata:
  name: "$serverName"
  namespace: "${NS}"
spec:
  ports:
  - name: tcp-6379
    protocol: TCP
    port: 6379
    targetPort: 6379
  - name: tcp-16379
    protocol: TCP
    port: 16379
    targetPort: 16379
  selector:
    k8s-app: "${serverName}"
  type: ClusterIP
---
kind: Deployment
apiVersion: extensions/v1beta1
metadata:
  name: "${serverName}"
  namespace: "${NS}"
  labels:
    k8s-app: "${serverName}"
spec:
  replicas: 1
  selector:
    matchLabels:
      k8s-app: "${serverName}"
  template:
    metadata:
      name: "${serverName}"
      labels:
        k8s-app: "${serverName}"
    spec:
      containers:
      - name: "${serverName}"
        image: docker.zyxr.com/tools/${name}
        resources:
          limits:
            memory: 256Mi
        imagePullPolicy: Always
      restartPolicy: Always
EOF
let ++n
done
#mq
cat >> test_env.yaml << EOF
---
kind: Service
apiVersion: v1
metadata:
  name: "mq-httpmanager"
  namespace: "${NS}"
spec:
  ports:
  - name: tcp-15672
    protocol: TCP
    port: 15672
    targetPort: 15672
    nodePort: ${MQManagerPort}
  selector:
    k8s-app: "mq1-exserver"
  type: NodePort
---
kind: Service
apiVersion: v1
metadata:
  name: "mq1-exserver"
  namespace: "${NS}"
spec:
  ports:
  - name: tcp-5672
    protocol: TCP
    port: 5672
    targetPort: 5672
  - name: tcp-15672
    protocol: TCP
    port: 15672
    targetPort: 15672
  selector:
    k8s-app: "mq1-exserver"
  type: ClusterIP
---
kind: Service
apiVersion: v1
metadata:
  name: "mq2-exserver"
  namespace: "${NS}"
spec:
  ports:
  - name: tcp-5672
    protocol: TCP
    port: 5672
    targetPort: 5672
  - name: tcp-15672
    protocol: TCP
    port: 15672
    targetPort: 15672
  selector:
    k8s-app: "mq1-exserver"
  type: ClusterIP
---
kind: Deployment
apiVersion: extensions/v1beta1
metadata:
  name: "mq1-exserver"
  namespace: "${NS}"
  labels:
    k8s-app: "mq1-exserver"
spec:
  replicas: 1
  selector:
    matchLabels:
      k8s-app: "mq1-exserver"
  template:
    metadata:
      name: "mq1-exserver"
      labels:
        k8s-app: "mq1-exserver"
    spec:
      containers:
      - name: "mq1-exserver"
        image: docker.zyxr.com/tools/rabbitmq:3.6.15-management-alpine
        resources:
          limits:
            memory: 260Mi
        imagePullPolicy: Always
      restartPolicy: Always  
EOF
#zk
cat >> test_env.yaml << EOF
---
kind: Service
apiVersion: v1
metadata:
  name: "zh-nodeport"
  namespace: "${NS}"
spec:
  ports:
  - name: tcp-2181
    protocol: TCP
    port: 2181
    targetPort: 2181
    nodePort: ${ZKPort}
  selector:
    k8s-app: "zk1-exserver"
  type: NodePort
---
kind: Service
apiVersion: v1
metadata:
  name: "zk1-exserver"
  namespace: "${NS}"
spec:
  ports:
  - name: tcp-2181
    protocol: TCP
    port: 2181
    targetPort: 2181
  selector:
    k8s-app: "zk1-exserver"
  type: ClusterIP
---
kind: Service
apiVersion: v1
metadata:
  name: "zk2-exserver"
  namespace: "${NS}"
spec:
  ports:
  - name: tcp-2181
    protocol: TCP
    port: 2181
    targetPort: 2181
  selector:
    k8s-app: "zk1-exserver"
  type: ClusterIP
---
kind: Service
apiVersion: v1
metadata:
  name: "zk3-exserver"
  namespace: "${NS}"
spec:
  ports:
  - name: tcp-2181
    protocol: TCP
    port: 2181
    targetPort: 2181
  selector:
    k8s-app: "zk1-exserver"
  type: ClusterIP
---
kind: Deployment
apiVersion: extensions/v1beta1
metadata:
  name: "zk-exserver"
  namespace: "${NS}"
  labels:
    k8s-app: "zk1-exserver"
spec:
  replicas: 1
  selector:
    matchLabels:
      k8s-app: "zk1-exserver"
  template:
    metadata:
      name: "zk1-exserver"
      labels:
        k8s-app: "zk1-exserver"
    spec:
      containers:
      - name: "zk1-exserver"
        image: docker.zyxr.com/tools/zookeeper
        resources:
          limits:
            memory: 260Mi
        imagePullPolicy: Always
      restartPolicy: Always  
EOF




kubectl create -f test_env.yaml