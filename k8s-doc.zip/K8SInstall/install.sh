#!/bin/sh
#megax create 2018.03.07

SCRIPT="$(readlink --canonicalize-existing "$0")"
BASEDIR="$(dirname "$SCRIPT")"
cd $BASEDIR

#--基础配置--------------------------------
#splunk先不装
VIP=192.168.10.20
INTERFACE=ens18
SERVICE_CIDR="10.151.0.0/16"

Masters=(
192.168.10.21:master1.k8s.zyxr.com
192.168.10.22:master2.k8s.zyxr.com
192.168.10.23:master3.k8s.zyxr.com
)

Nodes=(
192.168.10.24:node1.k8s.zyxr.com
192.168.10.25:node2.k8s.zyxr.com
192.168.10.26:node3.k8s.zyxr.com
192.168.10.27:node4.k8s.zyxr.com
192.168.10.28:node5.k8s.zyxr.com
)

rootpw=a123456

#IMG_pause="gcr.io/google_containers/pause-amd64:3.0"
#IMG_dashboard="k8s.gcr.io/kubernetes-dashboard-amd64:v1.8.3"
#IMG_heapster="k8s.gcr.io/heapster-amd64:v1.5.3"
#IMG_heapster_influxdb="k8s.gcr.io/heapster-influxdb-amd64:v1.3.3"
#IMG_heapster_grafana="k8s.gcr.io/heapster-grafana-amd64:v4.4.3"
#IMG_coredns="coredns/coredns:1.0.1"

IMG_pause="docker.zyxr.com/k8s/pause-amd64:3.0"
IMG_dashboard="docker.zyxr.com/k8s/kubernetes-dashboard-amd64:v1.8.3"
IMG_heapster="docker.zyxr.com/k8s/heapster-amd64:v1.5.3"
IMG_heapster_influxdb="docker.zyxr.com/k8s/heapster-influxdb-amd64:v1.3.3"
IMG_heapster_grafana="docker.zyxr.com/k8s/heapster-grafana-amd64:v4.4.3"
IMG_coredns="docker.zyxr.com/k8s/coredns:1.0.1"


# 服务网段 (Service CIDR），部署前路由不可达，部署后集群内使用 IP:Port 可达
export SERVICE_CIDR="10.151.0.0/16"
# kubernetes 服务 IP (预分配，一般是 SERVICE_CIDR 中第一个IP)
export CLUSTER_KUBERNETES_SVC_IP="10.151.0.1"
# 集群 DNS 服务 IP (从 SERVICE_CIDR 中预分配)
export CLUSTER_DNS_SVC_IP="10.151.0.2"


# POD 网段 (Cluster CIDR），部署前路由不可达，**部署后**路由可达 (flanneld 保证)
export CLUSTER_CIDR="10.150.0.0/16"

#--基础配置--------------------------------

#初始化安装环境
InitInstallEnv()
{
	yum install expect-5.45-14.el7_1.x86_64.rpm tcl-8.5.13-8.el7.x86_64.rpm -y
	rm ssh -rf
	rm ~/.ssh -rf
	mkdir ssh
	mkdir ~/.ssh
	
for master in ${Masters[@]}
do
	addKnowHosts_masterIp=`echo $master | awk -F ':' '{print $1}'`
	addKnowHosts_masterName=`echo $master | awk -F ':' '{print $2}'`
	addKnowHosts
done


expect <<!
set timeout -1
spawn ssh-keygen -t rsa -b 4096 -C ""
expect "*/.ssh/id_rsa):"
send "ssh/id_rsa\r"
expect "Enter passphrase (empty for no passphrase):"
send "\r"
expect "Enter same passphrase again:"
send "\r"
expect "*#"
interact
!

cat ssh/id_rsa.pub > ssh/authorized_keys

syncSSH_authorized_keys=`cat ssh/authorized_keys`
syncSSH_idrsa=`cat ssh/id_rsa`
syncSSH_idpub=`cat ssh/id_rsa.pub`
syncSSH_knownhosts=`cat ssh/known_hosts`

echo "$syncSSH_authorized_keys" > /root/.ssh/authorized_keys
echo "$syncSSH_idrsa" > /root/.ssh/id_rsa
echo "$syncSSH_idpub" > ~/.ssh/id_rsa.pub
echo "$syncSSH_knownhosts" > ~/.ssh/known_hosts

for master in ${Masters[@]}
do
	masterIp=`echo $master | awk -F ':' '{print $1}'`
  masterName=`echo $master | awk -F ':' '{print $2}'`
	syncSSH_Ip=$masterIp
	syncSSH_Name=$masterName
	syncSSH
done
	
}

#addKnowHosts_masterIp,addKnowHosts_masterName
addKnowHosts()
{
masterIp=$addKnowHosts_masterIp
masterName=$addKnowHosts_masterName
ssh-keyscan $masterIp >> ssh/known_hosts
ssh-keyscan $masterIp >>  ~/.ssh/known_hosts
}

#同步ssh到其他机器
#syncSSH_Ip,syncSSH_Name,syncSSH_authorized_keys,syncSSH_idrsa,syncSSH_idpub,syncSSH_knownhosts
syncSSH()
{
masterIp=$syncSSH_Ip
expect <<!
set timeout -1
spawn ssh root@$masterIp
expect "*password:"
send "$rootpw\r"
expect "*#"
send "mkdir -p ~/.ssh\r"
expect "*#"
send "echo \"$syncSSH_authorized_keys\" > /root/.ssh/authorized_keys;echo \"$syncSSH_idrsa\" > /root/.ssh/id_rsa; echo \"$syncSSH_idpub\" > ~/.ssh/id_rsa.pub;echo \"$syncSSH_knownhosts\" > ~/.ssh/known_hosts\r"
expect "*#"
send "chmod 600 ~/.ssh/id_rsa;chmod 644 ~/.ssh/id_rsa.pub\r"
expect "*#"
send "exit\r"
expect "*#"
interact
!
}

#关闭swap
#swapOff_ip
swapOff()
{
masterIp=$swapOff_ip
expect <<!
set timeout -1
spawn ssh root@$masterIp
expect "*#"
send "swapoff -a\r"
expect "*#"
send "chmod +x /etc/rc.d/rc.local;systemctl enable rc-local.service;echo \"swapoff -a\" >> /etc/rc.d/rc.local\r"
expect "*#"
send "exit\r"
expect "*#"
interact
!
}

#将全部master关闭swap
swapOffAllMaster()
{
	
for master in ${Masters[@]}
do
masterIp=`echo $master | awk -F ':' '{print $1}'`
masterName=`echo $master | awk -F ':' '{print $2}'`
swapOff_ip=$masterIp
swapOff
done
}

#创建基本配置
genEnv()
{
NewNID=`head -c 16 /dev/urandom | od -An -t x | tr -d ' '`	
cat > env.sh << EOF
# TLS Bootstrapping 使用的 Token，可以使用命令 head -c 16 /dev/urandom | od -An -t x | tr -d ' ' 生成
export BOOTSTRAP_TOKEN="$NewNID"
# 建议用 未用的网段 来定义服务网段和 Pod 网段

# 服务网段 (Service CIDR），部署前路由不可达，部署后集群内使用 IP:Port 可达
export SERVICE_CIDR="$SERVICE_CIDR"

# POD 网段 (Cluster CIDR），部署前路由不可达，**部署后**路由可达 (flanneld 保证)
export CLUSTER_CIDR="$CLUSTER_CIDR"

# 服务端口范围 (NodePort Range)
export NODE_PORT_RANGE="2000-9999"

# flanneld 网络配置前缀
export FLANNEL_ETCD_PREFIX="/kubernetes/network"

# kubernetes 服务 IP (预分配，一般是 SERVICE_CIDR 中第一个IP)
export CLUSTER_KUBERNETES_SVC_IP="$CLUSTER_KUBERNETES_SVC_IP"

# 集群 DNS 服务 IP (从 SERVICE_CIDR 中预分配)
export CLUSTER_DNS_SVC_IP="$CLUSTER_DNS_SVC_IP"

# 集群 DNS 域名
export CLUSTER_DNS_DOMAIN="cluster.local."

#export CGDriver="systemd"
export CGDriver="cgroupfs"


EOF

ETCD_ENDPOINTS=""
xMaster=""
for master in ${Masters[@]}
do
masterIp=`echo $master | awk -F ':' '{print $1}'`
masterName=`echo $master | awk -F ':' '{print $2}'`

if [ "$ETCD_ENDPOINTS" = "" ] 
then
   ETCD_ENDPOINTS="https://$masterIp:2379"
   xMaster="($masterIp:$masterName"
else
   ETCD_ENDPOINTS="$ETCD_ENDPOINTS,https://$masterIp:2379"
   xMaster="$xMaster $masterIp:$masterName"
fi
done
xMaster="$xMaster)"

xNode=""
for node in ${Nodes[@]}
do
masterIp=`echo $node | awk -F ':' '{print $1}'`
masterName=`echo $node | awk -F ':' '{print $2}'`

if [ "$xNode" = "" ] 
then
   xNode="($masterIp:$masterName"
else
   xNode="$xNode $masterIp:$masterName"
fi
done
xNode="$xNode)"

echo "# etcd 集群服务地址列表" >> env.sh
echo "export ETCD_ENDPOINTS=$ETCD_ENDPOINTS" >> env.sh
echo "export VIP=$VIP" >> env.sh
echo "export Masters=$xMaster" >> env.sh
echo "export Nodes=$xNode" >> env.sh

chmod +x env.sh
source ./env.sh
}

#同步env到其他机器
#syncEnvToOthers_ip
syncEnvTo()
{
	scp env.sh root@$syncEnvToOthers_ip:/usr/local/
}
#同步env到其他master
syncEnvToMasters()
{
for master in ${Masters[@]}
do
masterIp=`echo $master | awk -F ':' '{print $1}'`
masterName=`echo $master | awk -F ':' '{print $2}'`
syncEnvToOthers_ip=$masterIp
syncEnvTo
done
}

#设置主机名
#setHostName_ip,setHostName_name
setHostName()
{
expect <<!
set timeout -1
spawn ssh root@$setHostName_ip
expect "*#"
send "hostnamectl set-hostname $setHostName_name\r"
expect "*#"
send "sed -i 's/search /#search /' /etc/resolv.conf\r"
expect "*#"
send "exit\r"
expect "*#"
interact
!
}

#设置全部masterhostname
setAllMasterHostNames()
{
for master in ${Masters[@]}
do
masterIp=`echo $master | awk -F ':' '{print $1}'`
masterName=`echo $master | awk -F ':' '{print $2}'`
setHostName_ip=$masterIp
setHostName_name=$masterName
setHostName
done
}

#installcfssl_ip
installcfssl()
{
chmod +x cfssl*
scp cfssl* root@$installcfssl_ip:/usr/local/bin/
}

installcfssl2AllMaster()
{
for master in ${Masters[@]}
do
masterIp=`echo $master | awk -F ':' '{print $1}'`
masterName=`echo $master | awk -F ':' '{print $2}'`
installcfssl_ip=$masterIp
installcfssl
done	
}


#运行一个远程命令（无状态）
#runRCMD_ip,runRCMD_cmd
runRCMD()
{
expect <<!
set timeout -1
spawn ssh root@$runRCMD_ip
expect "*#"
send "$runRCMD_cmd\r"
expect "*#"
send "exit\r"
expect "*#"
interact
!
}

#创建CA证书
createCA()
{
cat >ca-config.json <<EOF
{
    "signing": {
        "default": {
            "expiry": "876000h"
        },
        "profiles": {
            "kubernetes": {
                "expiry": "876000h",
                "usages": [
                    "signing",
                    "key encipherment",
                    "server auth",
                    "client auth"
                ]
            }
        }
    }
}
EOF
cat >ca-csr.json <<EOF
{
    "CN": "kubernetes",
    "key": {
        "algo": "rsa",
        "size": 4096
    },
  	"names": [
    {
      "C": "CN",
      "O": "k8s",
      "OU": "System"
    }
  ]
}
EOF
cfssl gencert -initca ca-csr.json | cfssljson -bare ca -
}


#syncCA2Host_ip
syncCA2Host()
{
	runRCMD_ip=$syncCA2Host_ip
	runRCMD_cmd="mkdir -p /etc/kubernetes/ssl/"
	runRCMD
	scp -r ca* root@$syncCA2Host_ip:/etc/kubernetes/ssl/
}


syncCA2AllMasters()
{
for master in ${Masters[@]}
do
masterIp=`echo $master | awk -F ':' '{print $1}'`
masterName=`echo $master | awk -F ':' '{print $2}'`
syncCA2Host_ip=$masterIp
syncCA2Host
done
}


InitEtcdNodesUrl()
{
ETCD_NODES=""
for master in ${Masters[@]}
do
masterIp=`echo $master | awk -F ':' '{print $1}'`
masterName=`echo $master | awk -F ':' '{print $2}'`
if [ "$ETCD_NODES" = "" ] 
then
   ETCD_NODES="$masterName=https://$masterIp:2380"
 
else
   ETCD_NODES="$ETCD_NODES,$masterName=https://$masterIp:2380"
fi
done
tar xzfv etcd-v3.1.10-linux-amd64.tar.gz
}

#installEtcd_ip,installEtcd_name
installEtcd()
{
	
masterIp=$installEtcd_ip
masterName=$installEtcd_name

cat > etcd-csr.json <<EOF
{
  "CN": "etcd",
  "hosts": [
    "127.0.0.1",
    "$masterIp",
    "$masterName"
  ],
  "key": {
    "algo": "rsa",
    "size": 2048
  },
  "names": [
    {
      "C": "CN",
      "O": "k8s",
      "OU": "System"
    }
  ]
}
EOF

	scp -r etcd-csr.json root@$masterIp:/etc/kubernetes/ssl/
	scp -r etcd-v3.1.10-linux-amd64/etcd* root@$masterIp:/usr/local/bin/
	
expect <<!
set timeout -1
spawn ssh root@$masterIp
expect "*#"
send "cd /etc/kubernetes/ssl/\r"
expect "*#"
send "cfssl gencert -ca=/etc/kubernetes/ssl/ca.pem  -ca-key=/etc/kubernetes/ssl/ca-key.pem -config=/etc/kubernetes/ssl/ca-config.json -profile=kubernetes etcd-csr.json | cfssljson -bare etcd\r"
expect "*#"
send "exit\r"
expect "*#"
interact
!

NODE_NAME=$masterName
NODE_IP=$masterIp
cat > etcd.service <<EOF
[Unit]
Description=Etcd Server
After=network.target
After=network-online.target
Wants=network-online.target
Documentation=https://github.com/coreos

[Service]
Type=notify
WorkingDirectory=/var/lib/etcd/
ExecStart=/usr/local/bin/etcd --name $NODE_NAME \
    --data-dir /var/lib/etcd \
    --listen-client-urls https://$NODE_IP:2379 \
    --advertise-client-urls https://$NODE_IP:2379 \
    --listen-peer-urls https://$NODE_IP:2380 \
    --initial-advertise-peer-urls https://$NODE_IP:2380 \
    --cert-file=/etc/kubernetes/ssl/etcd.pem \
    --key-file=/etc/kubernetes/ssl/etcd-key.pem \
    --client-cert-auth \
    --trusted-ca-file=/etc/kubernetes/ssl/ca.pem \
    --peer-cert-file=/etc/kubernetes/ssl/etcd.pem \
    --peer-key-file=/etc/kubernetes/ssl/etcd-key.pem \
    --peer-client-cert-auth \
    --peer-trusted-ca-file=/etc/kubernetes/ssl/ca.pem \
    --initial-cluster ${ETCD_NODES} \
    --initial-cluster-token my-etcd-token \
    --initial-cluster-state new
Restart=on-failure
RestartSec=5
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target
EOF

scp -r etcd.service root@$masterIp:/etc/systemd/system/

expect <<!
set timeout -1
spawn ssh root@$masterIp
expect "*#"
send "mkdir -p /var/lib/etcd;systemctl daemon-reload; systemctl enable etcd; nohup systemctl start etcd >> /dev/null & \r\r"
expect "*#"
send "exit\r"
expect "*#"
interact
!


}



installEtcd2AllMasters()
{
for master in ${Masters[@]}
do
masterIp=`echo $master | awk -F ':' '{print $1}'`
masterName=`echo $master | awk -F ':' '{print $2}'`
installEtcd_ip=$masterIp
installEtcd_name=$masterName
installEtcd
done
}


cratekubernetesAdminCer()
{
cat > admin-csr.json <<EOF
{
  "CN": "admin",
  "hosts": [],
  "key": {
    "algo": "rsa",
    "size": 2048
  },
  "names": [
    {
      "C": "CN",
      "O": "system:masters",
      "OU": "System"
    }
  ]
}
EOF
cfssl gencert -ca=./ca.pem \
  -ca-key=./ca-key.pem \
  -config=./ca-config.json \
  -profile=kubernetes admin-csr.json | cfssljson -bare admin
}

#synckubernetesAdminCer_ip
synckubernetesAdminCer()
{
	scp -r admin*.pem root@$synckubernetesAdminCer_ip:/etc/kubernetes/ssl/
}

synckubernetesAdminCer2AllMaster()
{
for master in ${Masters[@]}
do
masterIp=`echo $master | awk -F ':' '{print $1}'`
masterName=`echo $master | awk -F ':' '{print $2}'`
synckubernetesAdminCer_ip=$masterIp
synckubernetesAdminCer
done
	
}

tarkubernetes()
{
	tar xzfv kubernetes-client-linux-amd64.tar.gz
	tar xzfv kubernetes-server-linux-amd64.tar.gz
}


#installkubernetes_ip,installkubernetes_name
installkubernetes()
{
	masterIp=$installkubernetes_ip
	masterName=$installkubernetes_name
	scp -r kubernetes/client/bin/kubectl root@$masterIp:/usr/local/bin/
}


installkubernetes2AllMasters()
{
for master in ${Masters[@]}
do
masterIp=`echo $master | awk -F ':' '{print $1}'`
masterName=`echo $master | awk -F ':' '{print $2}'`
installkubernetes_ip=$masterIp
installkubernetes_name=$masterName
installkubernetes
done
}

#-创建 kubectl kubeconfig 文件---
#master serverip设置为127.0.0.1，nodes设置为VIP
#createkubeconfig_ip,createkubeconfig_serverip
createkubeconfig()
{
expect <<!
set timeout -1
spawn ssh root@$createkubeconfig_ip
expect "*#"
send "kubectl config set-cluster kubernetes --certificate-authority=/etc/kubernetes/ssl/ca.pem --embed-certs=true --server=https://$createkubeconfig_serverip:6443\r"
expect "*#"
send "kubectl config set-credentials admin --client-certificate=/etc/kubernetes/ssl/admin.pem   --embed-certs=true   --client-key=/etc/kubernetes/ssl/admin-key.pem\r"
expect "*#"
send "kubectl config set-context kubernetes --cluster=kubernetes --user=admin ;kubectl config use-context kubernetes\r"
expect "*#"
send "exit \r"
expect "*#"
interact
!
}

createAllMasterkubeconfig()
{
for master in ${Masters[@]}
do
masterIp=`echo $master | awk -F ':' '{print $1}'`
masterName=`echo $master | awk -F ':' '{print $2}'`
createkubeconfig_ip=$masterIp
createkubeconfig_serverip="127.0.0.1"
createkubeconfig
done	
}


#-----安装master--------------------------------

initkubernetesMasterUrl()
{
AllMaster=""
for master in ${Masters[@]}
do
masterIp=`echo $master | awk -F ':' '{print $1}'`
masterName=`echo $master | awk -F ':' '{print $2}'`
if [ "$AllMaster" = "" ]
then
	AllMaster="\"$masterIp\",\"$masterName\""
else
	AllMaster="$AllMaster,\"$masterIp\",\"$masterName\""
fi
done

cat > kubernetes-csr.json <<EOF
{
  "CN": "kubernetes",
  "hosts": [
    "127.0.0.1",
     $AllMaster,
    "${VIP}",
    "${CLUSTER_KUBERNETES_SVC_IP}",
    "kubernetes",
    "kubernetes.default",
    "kubernetes.default.svc",
    "kubernetes.default.svc.cluster",
    "kubernetes.default.svc.cluster.local"
  ],
  "key": {
    "algo": "rsa",
    "size": 2048
  },
  "names": [
    {
      "C": "CN",
      "O": "k8s",
      "OU": "System"
    }
  ]
}
EOF
cfssl gencert -ca=ca.pem \
  -ca-key=ca-key.pem \
  -config=ca-config.json \
  -profile=kubernetes kubernetes-csr.json | cfssljson -bare kubernetes
  
  
cat > token.csv <<EOF
${BOOTSTRAP_TOKEN},kubelet-bootstrap,10001,"system:kubelet-bootstrap"
EOF
}

#installAllkubernetesMaster_ip,installAllkubernetesMaster_name
installAllkubernetesMaster()
{
	masterIp=$installAllkubernetesMaster_ip
	masterName=$installAllkubernetesMaster_name
	
scp kubernetes/server/bin/{kube-apiserver,kube-controller-manager,kube-scheduler,kubectl,kube-proxy,kubelet} root@$masterIp:/usr/local/bin/

scp -r kubernetes*.pem root@$masterIp:/etc/kubernetes/ssl/
scp -r  token.csv  root@$masterIp:/etc/kubernetes/
	
	
##--kube-apiserver.service------------------
cat  > kube-apiserver.service <<EOF
[Unit]
Description=Kubernetes API Server
Documentation=https://github.com/GoogleCloudPlatform/kubernetes
After=network.target

[Service]
ExecStart=/usr/local/bin/kube-apiserver \\
  --admission-control=NamespaceLifecycle,LimitRanger,ServiceAccount,DefaultStorageClass,ResourceQuota,NodeRestriction \\
  --advertise-address=${masterIp} \\
  --bind-address=0.0.0.0 \\
  --insecure-bind-address=0.0.0.0 \\
  --authorization-mode=Node,RBAC \\
#  --basic-auth-file=/etc/kubernetes/basic_auth_file \\
  --runtime-config=rbac.authorization.k8s.io/v1 \\
  --kubelet-https=true \\
  --enable-bootstrap-token-auth \\
  --token-auth-file=/etc/kubernetes/token.csv \\
  --service-cluster-ip-range=${SERVICE_CIDR} \\
  --service-node-port-range=${NODE_PORT_RANGE} \\
  --tls-cert-file=/etc/kubernetes/ssl/kubernetes.pem \\
  --tls-private-key-file=/etc/kubernetes/ssl/kubernetes-key.pem \\
  --client-ca-file=/etc/kubernetes/ssl/ca.pem \\
  --service-account-key-file=/etc/kubernetes/ssl/ca-key.pem \\
  --etcd-cafile=/etc/kubernetes/ssl/ca.pem \\
  --etcd-certfile=/etc/kubernetes/ssl/kubernetes.pem \\
  --etcd-keyfile=/etc/kubernetes/ssl/kubernetes-key.pem \\
  --etcd-servers=${ETCD_ENDPOINTS} \\
  --enable-swagger-ui=true \\
  --allow-privileged=true \\
  --apiserver-count=3 \\
  --audit-log-maxage=30 \\
  --audit-log-maxbackup=3 \\
  --audit-log-maxsize=100 \\
  --audit-log-path=/var/lib/audit.log \\
  --event-ttl=1h \\
  --v=2
Restart=on-failure
RestartSec=5
Type=notify
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target
EOF

scp -r kube-apiserver.service root@$masterIp:/etc/systemd/system/

#start kube-apiserver

expect<<!
set timeout -1
spawn ssh root@$masterIp
expect "*#"
send "touch /etc/kubernetes/basic_auth_file;systemctl daemon-reload;systemctl enable kube-apiserver;systemctl start kube-apiserver\r"
expect "*#"
send "systemctl status kube-apiserver\r"
expect "*#"
send "exit\r"
expect "*#"
interact
!

##-kube-controller-manager----------------

cat > kube-controller-manager.service <<EOF
[Unit]
Description=Kubernetes Controller Manager
Documentation=https://github.com/GoogleCloudPlatform/kubernetes

[Service]
ExecStart=/usr/local/bin/kube-controller-manager \\
  --address=127.0.0.1 \\
  --master=http://127.0.0.1:8080 \\
  --allocate-node-cidrs=true \\
  --service-cluster-ip-range=${SERVICE_CIDR} \\
  --cluster-cidr=${CLUSTER_CIDR} \\
  --cluster-name=kubernetes \\
  --cluster-signing-cert-file=/etc/kubernetes/ssl/ca.pem \\
  --cluster-signing-key-file=/etc/kubernetes/ssl/ca-key.pem \\
  --service-account-private-key-file=/etc/kubernetes/ssl/ca-key.pem \\
  --root-ca-file=/etc/kubernetes/ssl/ca.pem \\
  --leader-elect=true \\
  --v=2
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

scp -r kube-controller-manager.service root@$masterIp:/etc/systemd/system/

#start kube-controller-manager
expect<<!
set timeout -1
spawn ssh root@$masterIp
expect "*#"
send "systemctl daemon-reload;systemctl enable kube-controller-manager;systemctl start kube-controller-manager\r"
expect "*#"
send "systemctl status kube-controller-manager\r"
expect "*#"
send "exit\r"
expect "*#"
interact
!

#-kube-scheduler.service-----------------------------------
cat > kube-scheduler.service <<EOF
[Unit]
Description=Kubernetes Scheduler
Documentation=https://github.com/GoogleCloudPlatform/kubernetes

[Service]
ExecStart=/usr/local/bin/kube-scheduler \\
  --address=127.0.0.1 \\
  --master=http://127.0.0.1:8080 \\
  --leader-elect=true \\
  --v=2
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

scp -r kube-scheduler.service root@$masterIp:/etc/systemd/system/
expect<<!
set timeout -1
spawn ssh root@$masterIp
expect "*#"
send "systemctl daemon-reload;systemctl enable kube-scheduler.service;systemctl start kube-scheduler.service\r"
expect "*#"
send "systemctl status kube-scheduler\r"
expect "*#"
send "exit\r"
expect "*#"
interact
!



runRCMD_ip=$masterIp
runRCMD_cmd="kubectl create clusterrolebinding kubelet-bootstrap --clusterrole=system:node-bootstrapper --user=kubelet-bootstrap"
runRCMD
runRCMD_cmd="kubectl create clusterrolebinding admin-bind --clusterrole=cluster-admin --user=admin"
runRCMD
	
}

installkubernetesMaster2All()
{
for master in ${Masters[@]}
do
masterIp=`echo $master | awk -F ':' '{print $1}'`
masterName=`echo $master | awk -F ':' '{print $2}'`
installAllkubernetesMaster_ip=$masterIp
installAllkubernetesMaster_name=$masterName
installAllkubernetesMaster
done
}


#install keepalived
#installKeepalived_ip,installKeepalived_STATE,installKeepalived_INTERFACE,installKeepalived_priority
installKeepalived()
{	
masterIp=$installKeepalived_ip
cat > keepalived.conf <<EOF
! Configuration File for keepalived
 global_defs {
   router_id LVS_DEVEL
 }
    
 vrrp_script check_apiserver {
   script "/etc/keepalived/check_apiserver.sh"
   interval 3
   weight -2
   fall 10
   rise 2
 }
    
 vrrp_instance VI_1 {
     state $installKeepalived_STATE
     interface $installKeepalived_INTERFACE
     virtual_router_id 51
     priority $installKeepalived_priority
     authentication {
         auth_type PASS
         auth_pass $BOOTSTRAP_TOKEN
     }
     virtual_ipaddress {
         $VIP
     }
     track_script {
         check_apiserver
     }
 }
EOF
	
cat > check_apiserver.sh <<EOF
#!/bin/sh
 errorExit() {
     echo "*** $*" 1>&2
     exit 1
 }

 curl --silent --max-time 2 --insecure https://localhost:6443/ -o /dev/null || errorExit "Error GET https://localhost:6443/"
 if ip addr | grep -q $VIP; then
     curl --silent --max-time 2 --insecure https://$VIP:6443/ -o /dev/null || errorExit "Error GET https://$VIP:6443/"
 fi
EOF
chmod +x check_apiserver.sh

expect<<!
set timeout -1
spawn ssh root@$masterIp
expect "*#"
send "yum install -y keepalived\r"
expect "*~]#"
send "exit\r"
expect "*#"
interact
!

scp -r keepalived.conf root@$masterIp:/etc/keepalived/
scp -r check_apiserver.sh root@$masterIp:/etc/keepalived/

expect<<!
set timeout -1
spawn ssh root@$masterIp
expect "*#"
send "systemctl start keepalived && systemctl enable keepalived\r"
expect "*#"
send "exit\r"
expect "*#"
interact
!
	
}

installKeepAlived2AllMaster()
{
STATE="MASTER"
for master in ${Masters[@]}
do
masterIp=`echo $master | awk -F ':' '{print $1}'`
masterName=`echo $master | awk -F ':' '{print $2}'`
installKeepalived_ip=$masterIp
installKeepalived_STATE=$STATE
if [ "$STATE" = "MASTER" ]
then
	PPPPPP=101
	STATE="BACKUP"
else
	PPPPPP=100
fi
installKeepalived_INTERFACE=$INTERFACE
installKeepalived_priority=$PPPPPP
installKeepalived
done
}



#---Node---------------------------------
#---Node---------------------------------
#---Node---------------------------------
#---Node---------------------------------
#---Node---------------------------------
#---Node---------------------------------
#---Node---------------------------------
#---Node---------------------------------
#---Node---------------------------------

addNodesSSH()
{
for master in ${Nodes[@]}
do
	addKnowHosts_masterIp=`echo $master | awk -F ':' '{print $1}'`
	addKnowHosts_masterName=`echo $master | awk -F ':' '{print $2}'`
	addKnowHosts
done

cat ssh/id_rsa.pub > ssh/authorized_keys

syncSSH_authorized_keys=`cat ssh/authorized_keys`
syncSSH_idrsa=`cat ssh/id_rsa`
syncSSH_idpub=`cat ssh/id_rsa.pub`
syncSSH_knownhosts=`cat ssh/known_hosts`

echo "$syncSSH_authorized_keys" > /root/.ssh/authorized_keys
echo "$syncSSH_idrsa" > /root/.ssh/id_rsa
echo "$syncSSH_idpub" > ~/.ssh/id_rsa.pub
echo "$syncSSH_knownhosts" > ~/.ssh/known_hosts

for master in ${Nodes[@]}
do
	masterIp=`echo $master | awk -F ':' '{print $1}'`
  masterName=`echo $master | awk -F ':' '{print $2}'`
	syncSSH_Ip=$masterIp
	syncSSH_Name=$masterName
	syncSSH
done


}

swapoffAllNodes()
{
for master in ${Nodes[@]}
do
masterIp=`echo $master | awk -F ':' '{print $1}'`
masterName=`echo $master | awk -F ':' '{print $2}'`
swapOff_ip=$masterIp
swapOff
done
}

setHostName2AllNodes()
{
for master in ${Nodes[@]}
do
masterIp=`echo $master | awk -F ':' '{print $1}'`
masterName=`echo $master | awk -F ':' '{print $2}'`
setHostName_ip=$masterIp
setHostName_name=$masterName
setHostName
done
}

initDockerInstall()
{
cat << EOF > daemon.json
{
  "exec-opts": ["native.cgroupdriver=$CGDriver"]
}
EOF

cat <<EOF >  k8s.conf
net.bridge.bridge-nf-call-ip6tables = 1
net.bridge.bridge-nf-call-iptables = 1
EOF

cat > docker.service<<EOF
[Unit]
Description=Docker Application Container Engine
Documentation=https://docs.docker.com
After=network-online.target firewalld.service
Wants=network-online.target

[Service]
Type=notify
# the default is not to use systemd for cgroups because the delegate issues still
# exists and systemd currently does not support the cgroup feature set required
# for containers run by docker
EnvironmentFile=-/run/flannel/docker
ExecStart=/usr/bin/dockerd \$DOCKER_NETWORK_OPTIONS
ExecReload=/bin/kill -s HUP \$MAINPID
# Having non-zero Limit*s causes performance problems due to accounting overhead
# in the kernel. We recommend using cgroups to do container-local accounting.
LimitNOFILE=infinity
LimitNPROC=infinity
LimitCORE=infinity
# Uncomment TasksMax if your systemd version supports it.
# Only systemd 226 and above support this version.
#TasksMax=infinity
TimeoutStartSec=0
# set delegate yes so that systemd does not reset the cgroups of docker containers
Delegate=yes
# kill only the docker process, not all processes in the cgroup
KillMode=process
# restart the docker process if it exits prematurely
Restart=on-failure
StartLimitBurst=3
StartLimitInterval=60s

[Install]
WantedBy=multi-user.target
EOF

DockerTGZ=`ls docker-*-ce.tgz | head -n 1`
tar xzfv $DockerTGZ
}

#installDocker_ip
installDocker()
{
nodeIp=$installDocker_ip
scp -r docker/* root@$nodeIp:/usr/bin/
scp docker.service root@$nodeIp:/etc/systemd/system/

runRCMD_ip=$nodeIp
runRCMD_cmd="mkdir -p /etc/docker/"
runRCMD

scp -r daemon.json root@$nodeIp:/etc/docker/
scp -r k8s.conf root@$nodeIp:/etc/sysctl.d/
expect <<!
set timeout -1
spawn ssh root@$nodeIp
expect "*#"
send "sysctl --system;systemctl daemon-reload;systemctl enable docker\r"
expect "*#"
send "exit\r"
expect "*#"
interact
!
}

installDocker2AllNodes()
{
for master in ${Nodes[@]}
do
masterIp=`echo $master | awk -F ':' '{print $1}'`
masterName=`echo $master | awk -F ':' '{print $2}'`
installDocker_ip=$masterIp
installDocker
done
}

Initinstallflannel()
{
cat > flanneld-csr.json <<EOF
{
  "CN": "flanneld",
  "hosts": [],
  "key": {
    "algo": "rsa",
    "size": 2048
  },
  "names": [
    {
      "C": "CN",
      "O": "k8s",
      "OU": "System"
    }
  ]
}
EOF

cfssl gencert -ca=./ca.pem \
  -ca-key=./ca-key.pem \
  -config=./ca-config.json \
  -profile=kubernetes flanneld-csr.json | cfssljson -bare flanneld
  

mkdir -p /etc/flanneld/ssl/
cp flanneld*.pem   /etc/flanneld/ssl/ -Rf
  
etcdctl \
  --endpoints=${ETCD_ENDPOINTS} \
  --ca-file=/etc/kubernetes/ssl/ca.pem \
  --cert-file=/etc/flanneld/ssl/flanneld.pem \
  --key-file=/etc/flanneld/ssl/flanneld-key.pem \
  set ${FLANNEL_ETCD_PREFIX}/config '{"Network":"'${CLUSTER_CIDR}'", "SubnetLen": 24, "Backend": {"Type": "vxlan","VINT":1}}'  


flannelTGZ=`ls flannel-*-linux-amd64.tar.gz | head -n 1`

tar xzfv $flannelTGZ

cat > flanneld.service  <<EOF
[Unit]
Description=Flanneld overlay address etcd agent
After=network.target
After=network-online.target
Wants=network-online.target
After=etcd.service
Before=docker.service

[Service]
Type=notify
ExecStart=/usr/local/bin/flanneld \\
  -etcd-cafile=/etc/kubernetes/ssl/ca.pem \\
  -etcd-certfile=/etc/flanneld/ssl/flanneld.pem \\
  -etcd-keyfile=/etc/flanneld/ssl/flanneld-key.pem \\
  -etcd-endpoints=${ETCD_ENDPOINTS} \\
  -iface=${INTERFACE} \\
  -etcd-prefix=${FLANNEL_ETCD_PREFIX}
ExecStartPost=/usr/local/bin/mk-docker-opts.sh -k DOCKER_NETWORK_OPTIONS -d /run/flannel/docker
Restart=on-failure

[Install]
WantedBy=multi-user.target
RequiredBy=docker.service
EOF

}

#installflannel_ip
installflannel()
{
nodeIp=$installflannel_ip
expect <<!
set timeout -1
spawn ssh root@$nodeIp
expect "*#"
send "mkdir -p /etc/flanneld/ssl/;mkdir -p /etc/kubernetes/ssl/\r"
expect "*#"
send "exit\r"
expect "*#"
interact
!

scp -r {flanneld,mk-docker-opts.sh} root@$nodeIp:/usr/local/bin/
scp -r flanneld*.pem root@$nodeIp:/etc/flanneld/ssl/
scp -r flanneld.service root@$nodeIp:/etc/systemd/system/
scp -r ca.pem root@$nodeIp:/etc/kubernetes/ssl/
expect <<!
set timeout -1
spawn ssh root@$nodeIp
expect "*#"
send "systemctl daemon-reload;systemctl enable flanneld;systemctl start flanneld;systemctl start docker\r"
expect "*#"
send "exit\r"
expect "*#"
interact
!
}


installflannel2AllNodes()
{
for master in ${Nodes[@]}
do
masterIp=`echo $master | awk -F ':' '{print $1}'`
masterName=`echo $master | awk -F ':' '{print $2}'`
installflannel_ip=$masterIp
installflannel
done
}

syncCA2AllNodes()
{
for master in ${Nodes[@]}
do
masterIp=`echo $master | awk -F ':' '{print $1}'`
masterName=`echo $master | awk -F ':' '{print $2}'`
syncCA2Host_ip=$masterIp
syncCA2Host
done	
}

synckubernetesAdminCer2AllNodes()
{
for master in ${Nodes[@]}
do
masterIp=`echo $master | awk -F ':' '{print $1}'`
masterName=`echo $master | awk -F ':' '{print $2}'`
synckubernetesAdminCer_ip=$masterIp
synckubernetesAdminCer
done
	
}


#installNodeBin_ip
installNodeBin()
{
	scp -r kubernetes/server/bin/{kube-proxy,kubelet,kubectl} root@$installNodeBin_ip:/usr/local/bin/
}

installNodeBin2AllNodes()
{
for master in ${Nodes[@]}
do
masterIp=`echo $master | awk -F ':' '{print $1}'`
masterName=`echo $master | awk -F ':' '{print $2}'`
installNodeBin_ip=$masterIp
installNodeBin
done
}

#installkubelet_ip
installkubelet()
{
KUBE_APISERVER="https://${VIP}:6443"
NODE_IP=$installkubelet_ip
cat > kubelet.service <<EOF
[Unit]
Description=Kubernetes Kubelet
Documentation=https://github.com/GoogleCloudPlatform/kubernetes
After=docker.service
Requires=docker.service

[Service]
WorkingDirectory=/var/lib/kubelet
ExecStart=/usr/local/bin/kubelet \\
  --address=${NODE_IP} \\
  --hostname-override=${NODE_IP} \\
#  --pod-infra-container-image=registry.access.redhat.com/rhel7/pod-infrastructure:latest \\
  --pod-infra-container-image=${IMG_pause} \\
  --bootstrap-kubeconfig=/etc/kubernetes/bootstrap.kubeconfig \\
  --kubeconfig=/etc/kubernetes/kubelet.kubeconfig \\
  --cgroup-driver $CGDriver \\
  --cert-dir=/etc/kubernetes/ssl \\
  --eviction-hard=memory.available<2Gi \\
  --node-status-update-frequency=10s \\
  --eviction-pressure-transition-period=20s \\
  --system-reserved=cpu=200m,memory=1Gi \\
  --cluster-dns=${CLUSTER_DNS_SVC_IP} \\
  --cluster-domain=${CLUSTER_DNS_DOMAIN} \\
  --hairpin-mode promiscuous-bridge \\
  --allow-privileged=true \\
  --serialize-image-pulls=false \\
  --logtostderr=true \\
  --v=2
ExecStartPost=/sbin/iptables -A INPUT -s 10.0.0.0/8 -p tcp --dport 4194 -j ACCEPT
ExecStartPost=/sbin/iptables -A INPUT -s 172.16.0.0/12 -p tcp --dport 4194 -j ACCEPT
ExecStartPost=/sbin/iptables -A INPUT -s 192.168.0.0/16 -p tcp --dport 4194 -j ACCEPT
ExecStartPost=/sbin/iptables -A INPUT -p tcp --dport 4194 -j DROP
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

scp -r kubelet.service root@$installkubelet_ip:/etc/systemd/system/


expect<<!
set timeout -1
spawn ssh root@$installkubelet_ip
expect "*#"
send "kubectl config set-cluster kubernetes  --certificate-authority=/etc/kubernetes/ssl/ca.pem  --embed-certs=true  --server=${KUBE_APISERVER}  --kubeconfig=bootstrap.kubeconfig\r"
expect "*#"
send "kubectl config set-credentials kubelet-bootstrap --token=${BOOTSTRAP_TOKEN}   --kubeconfig=bootstrap.kubeconfig\r"
expect "*#"
send "kubectl config set-context default   --cluster=kubernetes   --user=kubelet-bootstrap   --kubeconfig=bootstrap.kubeconfig\r"
expect "*#"
send "kubectl config use-context default --kubeconfig=bootstrap.kubeconfig\r"
expect "*#"
send "mkdir -p /var/lib/kubelet;mv bootstrap.kubeconfig /etc/kubernetes/\r"
expect "*#"
send "systemctl daemon-reload;systemctl enable kubelet;systemctl start kubelet\r"
expect "*#"
send "systemctl status kubelet\r"
expect "*#"
send "exit\r"
expect "*#"
interact
!
	
}

installkubelet2AllNodes()
{
for master in ${Nodes[@]}
do
masterIp=`echo $master | awk -F ':' '{print $1}'`
masterName=`echo $master | awk -F ':' '{print $2}'`
installkubelet_ip=$masterIp
installkubelet
done
}


approveCSR()
{
ax=(1 2 3)
for xx in ${ax[@]}
do
csrss=`kubectl get csr | grep Pending | awk '{print $1}'`
for cc in ${csrss[@]}
do
kubectl certificate approve $cc
done
done
}


createAllNodekubeconfig()
{
for master in ${Nodes[@]}
do
masterIp=`echo $master | awk -F ':' '{print $1}'`
masterName=`echo $master | awk -F ':' '{print $2}'`
createkubeconfig_ip=$masterIp
createkubeconfig_serverip="$VIP"
createkubeconfig
done	
}

initKubeProxy()
{
cat > kube-proxy-csr.json<<EOF
{
  "CN": "system:kube-proxy",
  "hosts": [],
  "key": {
    "algo": "rsa",
    "size": 2048
  },
  "names": [
    {
      "C": "CN",
      "O": "k8s",
      "OU": "System"
    }
  ]
}
EOF


cfssl gencert -ca=ca.pem \
  -ca-key=ca-key.pem \
  -config=ca-config.json \
  -profile=kubernetes  kube-proxy-csr.json | cfssljson -bare kube-proxy


}

#installkubeproxy_ip
installkubeproxy()
{
KUBE_APISERVER="https://${VIP}:6443"
NODE_IP=$installkubeproxy_ip
scp -r kube-proxy*.pem root@$installkubeproxy_ip:/etc/kubernetes/ssl/


cat > kube-proxy.service <<EOF
[Unit]
Description=Kubernetes Kube-Proxy Server
Documentation=https://github.com/GoogleCloudPlatform/kubernetes
After=network.target

[Service]
WorkingDirectory=/var/lib/kube-proxy
ExecStart=/usr/local/bin/kube-proxy \\
  --bind-address=${NODE_IP} \\
  --hostname-override=${NODE_IP} \\
  --cluster-cidr=${CLUSTER_CIDR} \\
  --master=http://${VIP}:8080 \\
  --kubeconfig=/etc/kubernetes/kube-proxy.kubeconfig \\
  --logtostderr=true \\
  --v=2
Restart=on-failure
RestartSec=5
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target
EOF

scp -r kube-proxy.service root@$installkubeproxy_ip:/etc/systemd/system/

	
expect<<!
set timeout -1
spawn ssh root@$installkubeproxy_ip
expect "*#"
send "kubectl config set-cluster kubernetes   --certificate-authority=/etc/kubernetes/ssl/ca.pem   --embed-certs=true   --server=${KUBE_APISERVER}   --kubeconfig=kube-proxy.kubeconfig\r"
expect "*#"
send "kubectl config set-credentials kube-proxy   --client-certificate=/etc/kubernetes/ssl/kube-proxy.pem   --client-key=/etc/kubernetes/ssl/kube-proxy-key.pem   --embed-certs=true   --kubeconfig=kube-proxy.kubeconfig\r"
expect "*#"
send "kubectl config set-context default   --cluster=kubernetes   --user=kube-proxy   --kubeconfig=kube-proxy.kubeconfig\r"
expect "*#"
send "kubectl config use-context default --kubeconfig=kube-proxy.kubeconfig\r"
expect "*#"
send "mv kube-proxy.kubeconfig /etc/kubernetes/\r"
expect "*#"
send "mkdir -p /var/lib/kube-proxy;systemctl daemon-reload;systemctl enable kube-proxy;systemctl start kube-proxy\r"
expect "*#"
send "systemctl status kube-proxy\r"
expect "*#"
send "exit\r"
expect "*#"
interact
!
	
	
	
}

installkubeproxy2AllNodes()
{
for master in ${Nodes[@]}
do
masterIp=`echo $master | awk -F ':' '{print $1}'`
masterName=`echo $master | awk -F ':' '{print $2}'`
installkubeproxy_ip=$masterIp
installkubeproxy
done	
}

#updateSystem_ip
updateSystem()
{
expect<<!
set timeout -1
spawn ssh root@$updateSystem_ip
expect "*#"
send "yum clean all\r"
expect "*#"
send "yum update -y\r"
expect "*~]#"
send "yum clean all\r"
expect "*~]#"
send "exit\r"
expect "*~]#"
interact
!
}

updateAllMaster()
{
for master in ${Masters[@]}
do
masterIp=`echo $master | awk -F ':' '{print $1}'`
masterName=`echo $master | awk -F ':' '{print $2}'`
updateSystem_ip=$masterIp
updateSystem
done	
}

updateAllNodes()
{
for master in ${Nodes[@]}
do
masterIp=`echo $master | awk -F ':' '{print $1}'`
masterName=`echo $master | awk -F ':' '{print $2}'`
updateSystem_ip=$masterIp
updateSystem
done	
}


installCoreDNS()
{
source ./env.sh
DNS_DOMAIN=$CLUSTER_DNS_DOMAIN
SERVICE_CLUSTER_IP_RANGE=$SERVICE_CIDR
DNS_SERVER_IP=$CLUSTER_DNS_SVC_IP

#https://github.com/kubernetes/kubernetes/blob/v1.9.2/cluster/addons/dns/coredns.yaml.sed
cat >coredns.yaml <<EOF
apiVersion: v1
kind: ServiceAccount
metadata:
  name: coredns
  namespace: kube-system
  labels:
      kubernetes.io/cluster-service: "true"
      addonmanager.kubernetes.io/mode: Reconcile
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  labels:
    kubernetes.io/bootstrapping: rbac-defaults
    addonmanager.kubernetes.io/mode: Reconcile
  name: system:coredns
rules:
- apiGroups:
  - ""
  resources:
  - endpoints
  - services
  - pods
  - namespaces
  verbs:
  - list
  - watch
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  annotations:
    rbac.authorization.kubernetes.io/autoupdate: "true"
  labels:
    kubernetes.io/bootstrapping: rbac-defaults
    addonmanager.kubernetes.io/mode: EnsureExists
  name: system:coredns
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: system:coredns
subjects:
- kind: ServiceAccount
  name: coredns
  namespace: kube-system
---
apiVersion: v1
kind: ConfigMap
metadata:
  name: coredns
  namespace: kube-system
  labels:
      addonmanager.kubernetes.io/mode: EnsureExists
data:
  Corefile: |
    .:53 {
        errors
        log
        health
        kubernetes $DNS_DOMAIN $SERVICE_CLUSTER_IP_RANGE {
            pods insecure
        }
        prometheus
        proxy . /etc/resolv.conf
        cache 30
    }
---
apiVersion: extensions/v1beta1
kind: Deployment
metadata:
  name: coredns
  namespace: kube-system
  labels:
    k8s-app: coredns
    kubernetes.io/cluster-service: "true"
    addonmanager.kubernetes.io/mode: Reconcile
    kubernetes.io/name: "CoreDNS"
spec:
  replicas: 1
  selector:
    matchLabels:
      k8s-app: coredns
  template:
    metadata:
      labels:
        k8s-app: coredns
    spec:
      serviceAccountName: coredns
      tolerations:
        - key: node-role.kubernetes.io/master
          effect: NoSchedule
        - key: "CriticalAddonsOnly"
          operator: "Exists"
      containers:
      - name: coredns
        image: ${IMG_coredns}
        imagePullPolicy: IfNotPresent
        resources:
          limits:
            memory: 170Mi
          requests:
            cpu: 100m
            memory: 70Mi
        args: [ "-conf", "/etc/coredns/Corefile" ]
        volumeMounts:
        - name: config-volume
          mountPath: /etc/coredns
        ports:
        - containerPort: 53
          name: dns
          protocol: UDP
        - containerPort: 53
          name: dns-tcp
          protocol: TCP
        - containerPort: 9153
          name: metrics
          protocol: TCP
        livenessProbe:
          httpGet:
            path: /health
            port: 8080
            scheme: HTTP
          initialDelaySeconds: 60
          timeoutSeconds: 5
          successThreshold: 1
          failureThreshold: 5
      dnsPolicy: Default
      volumes:
        - name: config-volume
          configMap:
            name: coredns
            items:
            - key: Corefile
              path: Corefile
---
apiVersion: v1
kind: Service
metadata:
  name: coredns
  namespace: kube-system
  labels:
    k8s-app: coredns
    kubernetes.io/cluster-service: "true"
    addonmanager.kubernetes.io/mode: Reconcile
    kubernetes.io/name: "CoreDNS"
spec:
  selector:
    k8s-app: coredns
  clusterIP: $DNS_SERVER_IP
  ports:
  - name: dns
    port: 53
    protocol: UDP
  - name: dns-tcp
    port: 53
    protocol: TCP
  - name: metrics
    port: 9153
    protocol: TCP
EOF
kubectl create -f  coredns.yaml 

}

installdashboard()
{
	cat > kubernetes-dashboard.yaml	<<EOF
apiVersion: v1
kind: ServiceAccount
metadata:
  name: kubernetes-dashboard
  namespace: kube-system
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: kubernetes-dashboard
  labels:
    k8s-app: kubernetes-dashboard
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: cluster-admin
subjects:
- kind: ServiceAccount
  name: kubernetes-dashboard
  namespace: kube-system
---
kind: Deployment
apiVersion: apps/v1beta2
metadata:
  labels:
    k8s-app: kubernetes-dashboard
  name: kubernetes-dashboard
  namespace: kube-system
spec:
  replicas: 1
  revisionHistoryLimit: 10
  selector:
    matchLabels:
      k8s-app: kubernetes-dashboard
  template:
    metadata:
      labels:
        k8s-app: kubernetes-dashboard
    spec:
      serviceAccountName: kubernetes-dashboard
      containers:
      - name: kubernetes-dashboard
        image: ${IMG_dashboard}
        ports:
        - containerPort: 9090
          protocol: TCP
        args:
          - --heapster-host=http://heapster
          #- --auto-generate-certificates
          # Uncomment the following line to manually specify Kubernetes API server Host
          # If not specified, Dashboard will attempt to auto discover the API server and connect
          # to it. Uncomment only if the default does not work.
          # - --apiserver-host=http://my-address:port
        livenessProbe:
          httpGet:
            scheme: HTTP
            path: /
            port: 9090
          initialDelaySeconds: 30
          timeoutSeconds: 30
      tolerations:
      - key: node-role.kubernetes.io/master
        effect: NoSchedule
---
apiVersion: v1
kind: Service
metadata:
  name: kubernetes-dashboard
  namespace: kube-system
  labels:
    k8s-app: kubernetes-dashboard
    kubernetes.io/cluster-service: "true"
    addonmanager.kubernetes.io/mode: Reconcile
spec:
  selector:
    k8s-app: kubernetes-dashboard
  type: NodePort
  ports:
  - port: 9090
    targetPort: 9090
    nodePort: 8601
EOF

#kubectl apply -f https://raw.githubusercontent.com/kubernetes/dashboard/master/src/deploy/recommended/kubernetes-dashboard.yaml	
kubectl apply -f 	kubernetes-dashboard.yaml

}



#--fun--------------------------------

installheapster(){
#    kubectl create -f https://raw.githubusercontent.com/kubernetes/heapster/master/deploy/kube-config/rbac/heapster-rbac.yaml
#    kubectl create -f https://raw.githubusercontent.com/kubernetes/heapster/master/deploy/kube-config/influxdb/grafana.yaml
#    kubectl create -f https://raw.githubusercontent.com/kubernetes/heapster/master/deploy/kube-config/influxdb/heapster.yaml
#    kubectl create -f https://raw.githubusercontent.com/kubernetes/heapster/master/deploy/kube-config/influxdb/influxdb.yaml
cat > heapster-rbac.yaml <<EOF
kind: ClusterRoleBinding
apiVersion: rbac.authorization.k8s.io/v1beta1
metadata:
  name: heapster
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: system:heapster
subjects:
- kind: ServiceAccount
  name: heapster
  namespace: kube-system
EOF
#
cat > grafana.yaml <<EOF
apiVersion: extensions/v1beta1
kind: Deployment
metadata:
  name: monitoring-grafana
  namespace: kube-system
spec:
  replicas: 1
  template:
    metadata:
      labels:
        task: monitoring
        k8s-app: grafana
    spec:
      containers:
      - name: grafana
        image: ${IMG_heapster_grafana}
        ports:
        - containerPort: 3000
          protocol: TCP
        volumeMounts:
        - mountPath: /etc/ssl/certs
          name: ca-certificates
          readOnly: true
        - mountPath: /var
          name: grafana-storage
        env:
        - name: INFLUXDB_HOST
          value: monitoring-influxdb
        - name: GF_SERVER_HTTP_PORT
          value: "3000"
          # The following env variables are required to make Grafana accessible via
          # the kubernetes api-server proxy. On production clusters, we recommend
          # removing these env variables, setup auth for grafana, and expose the grafana
          # service using a LoadBalancer or a public IP.
        - name: GF_AUTH_BASIC_ENABLED
          value: "false"
        - name: GF_AUTH_ANONYMOUS_ENABLED
          value: "true"
        - name: GF_AUTH_ANONYMOUS_ORG_ROLE
          value: Admin
        - name: GF_SERVER_ROOT_URL
          # If you're only using the API Server proxy, set this value instead:
          # value: /api/v1/namespaces/kube-system/services/monitoring-grafana/proxy
          value: /
      volumes:
      - name: ca-certificates
        hostPath:
          path: /etc/ssl/certs
      - name: grafana-storage
        emptyDir: {}
---
apiVersion: v1
kind: Service
metadata:
  labels:
    # For use as a Cluster add-on (https://github.com/kubernetes/kubernetes/tree/master/cluster/addons)
    # If you are NOT using this as an addon, you should comment out this line.
    kubernetes.io/cluster-service: 'true'
    kubernetes.io/name: monitoring-grafana
  name: monitoring-grafana
  namespace: kube-system
spec:
  # In a production setup, we recommend accessing Grafana through an external Loadbalancer
  # or through a public IP.
  # type: LoadBalancer
  # You could also use NodePort to expose the service at a randomly-generated port
  # type: NodePort
  ports:
  - port: 80
    targetPort: 3000
  selector:
    k8s-app: grafana
EOF
###
cat > heapster.yaml <<EOF
apiVersion: v1
kind: ServiceAccount
metadata:
  name: heapster
  namespace: kube-system
---
apiVersion: extensions/v1beta1
kind: Deployment
metadata:
  name: heapster
  namespace: kube-system
spec:
  replicas: 1
  template:
    metadata:
      labels:
        task: monitoring
        k8s-app: heapster
    spec:
      serviceAccountName: heapster
      containers:
      - name: heapster
        image: ${IMG_heapster}
        imagePullPolicy: IfNotPresent
        command:
        - /heapster
        - --source=kubernetes:https://kubernetes.default
        - --sink=influxdb:http://monitoring-influxdb.kube-system.svc:8086
---
apiVersion: v1
kind: Service
metadata:
  labels:
    task: monitoring
    # For use as a Cluster add-on (https://github.com/kubernetes/kubernetes/tree/master/cluster/addons)
    # If you are NOT using this as an addon, you should comment out this line.
    kubernetes.io/cluster-service: 'true'
    kubernetes.io/name: Heapster
  name: heapster
  namespace: kube-system
spec:
  ports:
  - port: 80
    targetPort: 8082
  selector:
    k8s-app: heapster
EOF
###
cat > influxdb.yaml <<EOF
apiVersion: extensions/v1beta1
kind: Deployment
metadata:
  name: monitoring-influxdb
  namespace: kube-system
spec:
  replicas: 1
  template:
    metadata:
      labels:
        task: monitoring
        k8s-app: influxdb
    spec:
      containers:
      - name: influxdb
        image: ${IMG_heapster_influxdb}
        volumeMounts:
        - mountPath: /data
          name: influxdb-storage
      volumes:
      - name: influxdb-storage
        emptyDir: {}
---
apiVersion: v1
kind: Service
metadata:
  labels:
    task: monitoring
    # For use as a Cluster add-on (https://github.com/kubernetes/kubernetes/tree/master/cluster/addons)
    # If you are NOT using this as an addon, you should comment out this line.
    kubernetes.io/cluster-service: 'true'
    kubernetes.io/name: monitoring-influxdb
  name: monitoring-influxdb
  namespace: kube-system
spec:
  ports:
  - port: 8086
    targetPort: 8086
  selector:
    k8s-app: influxdb
EOF

kubectl create -f heapster-rbac.yaml
kubectl create -f grafana.yaml
kubectl create -f heapster.yaml
kubectl create -f influxdb.yaml
   
}



InitMasters()
{
	InitInstallEnv
	swapOffAllMaster
	genEnv
#手动更新系统到最新
#	updateAllMaster
	syncEnvToMasters
	setAllMasterHostNames
	installcfssl2AllMaster
	createCA
	syncCA2AllMasters
	InitEtcdNodesUrl
	installEtcd2AllMasters
	cratekubernetesAdminCer
	synckubernetesAdminCer2AllMaster
	tarkubernetes
	installkubernetes2AllMasters
	createAllMasterkubeconfig
	initkubernetesMasterUrl
	installkubernetesMaster2All
	
	#阿里云不用装，阿里云用slb，开放端口6443，指向到各master
	installKeepAlived2AllMaster
	
	
	
}

InitNodes()
{
	addNodesSSH
	swapoffAllNodes
#	updateAllNodes
	setHostName2AllNodes
	initDockerInstall
	installDocker2AllNodes
	Initinstallflannel
	installflannel2AllNodes
#---test
	etcdctl \
  --endpoints=${ETCD_ENDPOINTS} \
  --ca-file=/etc/kubernetes/ssl/ca.pem \
  --cert-file=/etc/flanneld/ssl/flanneld.pem \
  --key-file=/etc/flanneld/ssl/flanneld-key.pem \
  get ${FLANNEL_ETCD_PREFIX}/config
  
# 查看已分配的 Pod 子网段列表(/24)
etcdctl \
  --endpoints=${ETCD_ENDPOINTS} \
  --ca-file=/etc/kubernetes/ssl/ca.pem \
  --cert-file=/etc/flanneld/ssl/flanneld.pem \
  --key-file=/etc/flanneld/ssl/flanneld-key.pem \
  ls ${FLANNEL_ETCD_PREFIX}/subnets
	#----
	
	installNodeBin2AllNodes
	
	syncCA2AllNodes
	synckubernetesAdminCer2AllNodes
	
	createAllNodekubeconfig
	installkubelet2AllNodes
	sleep 3
	approveCSR
	initKubeProxy
	installkubeproxy2AllNodes
	
	sleep 3
	installCoreDNS
	installdashboard
	installheapster
}

AddNode(){
    source ./env.sh
	masterIp=`echo $1 | awk -F ':' '{print $1}'`
	masterName=`echo $1 | awk -F ':' '{print $2}'`

#------addNodesSSH
	addKnowHosts_masterIp=`echo $1 | awk -F ':' '{print $1}'`
	addKnowHosts_masterName=`echo $1 | awk -F ':' '{print $2}'`
	addKnowHosts
	cat ssh/id_rsa.pub > ssh/authorized_keys
	syncSSH_authorized_keys=`cat ssh/authorized_keys`
	syncSSH_idrsa=`cat ssh/id_rsa`
	syncSSH_idpub=`cat ssh/id_rsa.pub`
	syncSSH_knownhosts=`cat ssh/known_hosts`

	echo "$syncSSH_authorized_keys" > /root/.ssh/authorized_keys
	echo "$syncSSH_idrsa" > /root/.ssh/id_rsa
	echo "$syncSSH_idpub" > ~/.ssh/id_rsa.pub
	echo "$syncSSH_knownhosts" > ~/.ssh/known_hosts
	
	syncSSH_Ip=$masterIp
	syncSSH_Name=$masterName
	syncSSH
#------swapoff
	swapOff_ip=$masterIp
	swapOff	
#------setHostName2
	setHostName_ip=$masterIp
	setHostName_name=$masterName
	setHostName
#------initDockerInstall
	initDockerInstall
#------installDocker2
	installDocker_ip=$masterIp
	installDocker
#------Initinstallflannel
#	Initinstallflannel
#------installflannel2	
	installflannel_ip=$masterIp
	installflannel
#------installNodeBin2
	installNodeBin_ip=$masterIp
	installNodeBin
#------syncCA2
	syncCA2Host_ip=$masterIp
	syncCA2Host
#------synckubernetesAdminCer2
	synckubernetesAdminCer_ip=$masterIp
	synckubernetesAdminCer
#------createAllNodekubeconfig
	createkubeconfig_ip=$masterIp
	createkubeconfig_serverip="$VIP"
	createkubeconfig
#------installkubelet2AllNodes
	installkubelet_ip=$masterIp
	installkubelet
	sleep 3
#------initKubeProxy
#	initKubeProxy
	approveCSR
#------installkubeproxy2AllNodes	
	installkubeproxy_ip=$masterIp
	installkubeproxy
}


if [ "$1" == "add_node" ]; then
    AddNode $2
else
   InitMasters
   InitNodes
fi
